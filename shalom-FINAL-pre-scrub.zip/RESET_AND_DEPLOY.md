# HDGL Reset And Redeploy Runbook

This runbook is aligned with the current repository behavior in `deploy_hdgl.sh`,
`hdgl_host.py`, `hdgl_ingress.py`, and `hdgl_node_server.py`.

Use this for a clean redeploy on each node.

---

## 1. Full reset on a node

```bash
# Stop daemon if present
sudo systemctl stop hdgl-daemon 2>/dev/null || true

# Remove HDGL runtime/state directories
sudo rm -rf /opt/hdgl /opt/hdgl_swap /opt/hdgl_cache /var/log/hdgl

# Remove HDGL-managed nginx artifacts
sudo rm -f /etc/nginx/conf.d/living_network.conf
sudo rm -f /etc/nginx/conf.d/living_network.conf.bak
sudo rm -f /etc/nginx/conf.d/hdgl_upstreams.conf

# Validate base nginx still loads
sudo nginx -t && sudo systemctl reload nginx
```

Notes:
- `deploy_hdgl.sh` recreates `/opt/hdgl`, `.env`, service unit, and logrotate.
- Firewall rules are host-policy specific; use your distro policy (UFW or iptables)
  and then verify peer access on TCP 8090.

---

## 2. Upload deployment files

From your workstation:

```bash
scp hdgl_lattice.py hdgl_fileswap.py hdgl_node_server.py hdgl_ingress.py \
    hdgl_host.py hdgl_dns.py hdgl_moire.py hdgl_netboot.py hdgl_state_db.py \
    hdgl_audit.py hdgl_stability_sim.py hdgl_verify_and_readme.py \
    deploy_hdgl.sh \
    root@NODE_IP:/root/hdgl_deploy/
```

`hdgl_moire_c.so` is optional and can be copied when available.

---

## 3. Run deploy script

On each node:

```bash
cd /root/hdgl_deploy
sudo HDGL_LOCAL_NODE=THIS_NODE_IP \
     HDGL_PEER_NODES=OTHER_NODE_IP \
     bash deploy_hdgl.sh
```

Expected deploy behavior:
- installs dependencies
- writes `/opt/hdgl/.env` with `LN_SIMULATION=1` and `LN_DRY_RUN=1`
- installs and starts `hdgl-daemon`

---

## 4. Go live on each node

Set one shared secret value on all cluster nodes:

```bash
SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
echo "$SECRET"
```

Apply per node:

```bash
sudo sed -i "s/LN_CLUSTER_SECRET=.*/LN_CLUSTER_SECRET=$SECRET/" /opt/hdgl/.env
sudo sed -i 's/LN_SIMULATION=.*/LN_SIMULATION=0/' /opt/hdgl/.env
sudo sed -i 's/LN_DRY_RUN=.*/LN_DRY_RUN=0/' /opt/hdgl/.env
sudo systemctl restart hdgl-daemon
```

Optional (non-root daemon certbot control):

```bash
grep -q '^LN_CERTBOT_ENABLED=' /opt/hdgl/.env \
  && sudo sed -i 's/LN_CERTBOT_ENABLED=.*/LN_CERTBOT_ENABLED=0/' /opt/hdgl/.env \
  || echo 'LN_CERTBOT_ENABLED=0' | sudo tee -a /opt/hdgl/.env
sudo systemctl restart hdgl-daemon
```

---

## 5. Verify cluster and routing

```bash
# Health/API
curl -s http://THIS_NODE_IP:8090/health
curl -s http://THIS_NODE_IP:8090/node_info | python3 -m json.tool
curl -s http://THIS_NODE_IP:8090/metrics   | python3 -m json.tool
curl -s http://THIS_NODE_IP:8090/strand_map | python3 -m json.tool

# Logs
tail -f /var/log/hdgl/daemon.log
```

Look for cycle summaries with:
- `peers=...`
- `cluster=...`
- `fp_match=.../32`
- `my_strands=[...]`

---

## 6. Optional controlled failover check

```bash
# On one node, watch authority state
watch -n 3 'curl -s http://THIS_NODE_IP:8090/node_info | python3 -m json.tool'

# On peer node, stop daemon briefly
sudo systemctl stop hdgl-daemon
# then restart
sudo systemctl start hdgl-daemon
```

Authority ownership should rebalance automatically without static role edits.

---

## References

- Primary docs: `README.md`
- Snippet-to-source validation: `COMMAND_VERIFICATION_MATRIX.md`
